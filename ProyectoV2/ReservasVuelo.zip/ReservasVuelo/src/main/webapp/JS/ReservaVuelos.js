var ReservaVuelos = function(){
  /*this.fechaIni = document.getElementById("").value;
  this.fechaFin = document.getElementById("").value;*/
}
ReservaVuelos.prototype.comprobarFechas = function(fechaIni, fechaFin){

}
ReservaVuelos.prototype.validarCosteMaximo = function(campo){

}
